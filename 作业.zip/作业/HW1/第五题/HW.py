import math

def DoSomething(A, p, r):
    n = r - p + 1
    if n == 2 and A[p] > A[r]:
        A[p], A[r] = A[r], A[p]
    elif n >= 3:
        m = math.ceil(2 * n / 3)
        DoSomething(A, p, p + m - 1)
        DoSomething(A, r - m + 1, r)
        DoSomething(A, p, p + m - 1)

arr = input("请输入数组：")
A = list(map(int, arr.strip().split()))
DoSomething(A, 0, len(A) - 1)
print(A)