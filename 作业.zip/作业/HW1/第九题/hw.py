'''
def BB(A, p, r, k):
#定义黑盒BB

def quicksort(A, p, r, k):
    if p == r:
        return A[p]
#定义修改后的快速排序，如果只有一个数直接输出这个数

    pivot_index = BB(A, p, r, (r - p + 1) // 2)
    pivot_value = A[pivot_index]
#用这个黑盒选择出更为合适的快排轴，并选中这个轴


    select = partition(A, p, r, pivot_value)
#把小于和大于这个轴的分别放在两侧


    if k == select:
        return A[k]
    elif k < select:
        return quicksort(A, p, partition_index - 1, k)
    else:
        return quicksort(A, partition_index + 1, r, k)
#常规的递归处理

def partition(A, p, r, pivot_value):
#用于分组的函数
'''



'''
def smallest(A, p, r, k):
    index = BB(A, p, r, k)
    number = A[index]
#用BB找到第K小的值，并获得这个值的具体数字
    
 
    arr = []
    for i in range(p, r + 1):
        if A[i] <= number:
            arr.append(A[i])
#遍历数组找到所有小于等于K的数
    
    
    arr.sort()
#将数组排序
    
    return arr[:k]
'''


'''
def section(A, k)
    n = length(A)
    if k == 1 THEN RETURN A 
#如果只需要划分一次的时候递归终止
    
    pivot_pos = BB(A, 0, n - 1, n / k)
    x = A[pivot_pos]
#用BB函数找到第k小的从而选取中轴

    left = [a in A if a <= x]
    right = [a in A if a if a > x]
 #将数组划分为两部分，比中轴小的放左边，比中轴大的放右边
 
        section(left, k / 2),
        section(right, k / 2)
#通过递归不断划分区域，直到分到需要的模块，并且每个模块都比后面模块小。


'''