def alg(nums):
    count = 0
    a = None
    for num in nums:
        if count == 0:
            a = num
        if num == a:
            count = count + 1
        else:
            count = count - 1
    return a

arr = input("请输入数组元素，用空格分隔：")
nums = list(map(int, arr.strip().split()))
max = alg(nums)
print("多数元素是：", max)
print("time=O(n)")