def first(A):
    left = 1
    right = len(A) - 2
    while left <= right:
        mid = (left + right) // 2
        if A[mid] < A[mid - 1] and A[mid] < A[mid + 1]:
            return A[mid]
        elif A[mid - 1] < A[mid]:
            right = mid - 1
        else:
            left = mid + 1
    return None

def second(A):
    result = []
    for i in range(1, len(A) - 1):
        if A[i] < A[i - 1] and A[i] < A[i + 1]:
            result.append(A[i])
    return result

arr = input("请输入数组：")
A = list(map(int, arr.strip().split()))

small = first(A)
min = second(A)

print("任意一个局部最小值：", small)
print("time1=O(nlogn)")
print("所有局部最小值：", min)
print("time2=O(n)")
