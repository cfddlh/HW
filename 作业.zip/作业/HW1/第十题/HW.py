def sort(arr):
    max1 = max(len(s) for s in arr)

    for i in range(max1 - 1, -1, -1):
        alp = [[] for _ in range(26)]
        for s in arr:
            if i < len(s):
                index = ord(s[i]) - ord('a') + 1
            else:
                index = 0

            alp[index].append(s)
        arr = [s for al in alp for s in al]

    return arr

input_str = input("请输入字符串：")
A = input_str.strip().split()

sortA = sort(A)
print("排序后的数组：", sortA)
print("time=O(n)")