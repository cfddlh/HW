def Sprofit(changes):
    if len(changes) < 1:
        return 0, None, None

    prices = [0]
    for change in changes:
        prices.append(prices[-1] + change)

    min = prices[0]
    max = 0
    buy = 0
    sell = 0

    for i in range(1, len(prices)):
        if prices[i] - min > max:
            max = prices[i] - min
            sell = i
        if prices[i] < min:
            min = prices[i]
            buyA = i

    if sell <= buyA:
        return 0, None, None

    return max, buyA, sell


def main():
    print("输入每日涨跌幅")

    while True:
        input_str = input().strip()
        if input_str.lower() == 'exit':
            break

        try:
            changes = list(map(int, input_str.split()))
            profit, buy, sell = Sprofit(changes)

            if profit > 0:
                print(f"最大利润: {profit}")
                print(f"买入日: 第{buy}天")
                print(f"卖出日: 第{sell}天")
            else:
                print("没有获利机会")

        except ValueError:
            print("输入错误")


if __name__ == "__main__":
    main()