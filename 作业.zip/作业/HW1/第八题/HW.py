import heapq

def sort(arr):
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and arr[j] > key:
            arr[j + 1] = arr[j]
            j = j - 1
        arr[j + 1] = key
    return arr

def sort2(arr, k):
    heap = []
    for num in arr:
        heapq.heappush(heap, num)
    result = []
    for _ in range(k):
        result.append(heapq.heappop(heap))
    return result

def sort3(stream, k):
    heap = []
    for x in stream:
        if len(heap) < k:
            heapq.heappush(heap, -x)
        else:
            if x < -heap[0]:
                heapq.heappop(heap)
                heapq.heappush(heap, -x)
    return sorted([-x for x in heap])

input_str = input("请输入数组：")
k = int(input("请输入k："))

arr1 = list(map(int, input_str.strip().split()))
arr2 = arr1.copy()
arr3 = arr1.copy()

sort4 = sort(arr1)
print("第一问：", sort4[:k])
print("第一问排序结果：", sort4)
print("第二问：", sort2(arr2, k))
print("time2=O((n+k)*logn)")
print("第三问：", sort3(arr3, k))
print("time3=O(nlogk)")