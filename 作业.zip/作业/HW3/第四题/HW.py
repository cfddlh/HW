def jump(n):
    if n <= 2:
        return n
    a = 1
    b = 2
    for i in range(3, n + 1):
        c = a + b
        a = b
        b = c
    return b

x = int(input("输入楼梯阶数："))
print("爬法种类：", jump(x))
print("time = O(n)")