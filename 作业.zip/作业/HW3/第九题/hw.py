class Node:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def tree(s):
    lst = s.strip().split()
    if not lst or lst[0] == 'None':
        return None
    lst = [None if x == 'None' else int(x) for x in lst]
    root = Node(lst[0])
    q = [root]
    i = 1
    while q and i < len(lst):
        now = q.pop(0)
        if i < len(lst) and lst[i] is not None:
            now.left = Node(lst[i])
            q.append(now.left)
        i += 1
        if i < len(lst) and lst[i] is not None:
            now.right = Node(lst[i])
            q.append(now.right)
        i += 1
    return root

def sum(root, sum1=0):
    if not root:
        return 0
    sum1 = sum1 * 10 + root.val
    if not root.left and not root.right:  # 如果是叶子节点
        return sum1
    return sum(root.left, sum1) + sum(root.right, sum1)

s = input("请输入树的层序遍历：")
root = tree(s)
result = sum(root)
print("所有路径的数字之和是:", result)
print("time=O(n)")