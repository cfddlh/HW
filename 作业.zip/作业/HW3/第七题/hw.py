a = [5000, 3000, 2000]

b = [5000 * 0.10, 3000 * 0.08, 2000 * 0.12]

n = 3

k = int(input("请输入你的投资预算K："))

dp = [0] * (k + 1)

for i in range(n):
    j = k
    while j >= a[i]:
        if dp[j - a[i]] + b[i] > dp[j]:
            dp[j] = dp[j - a[i]] + b[i]
        j = j - 1

print("最大收益为：", int(dp[k]))
print("time=O(nk)")