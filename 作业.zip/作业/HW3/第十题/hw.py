from collections import deque
class T:
    def __init__(self, v=0, l=None, r=None):
        self.val = v
        self.left = l
        self.right = r

def make(s):
    lst = s.strip().split()
    if not lst or lst[0] == 'None':
        return None
    lst = [None if x == 'None' else int(x) for x in lst]
    root = T(lst[0])
    q = [root]
    i = 1
    while q and i < len(lst):
        now = q.pop(0)
        if i < len(lst) and lst[i] is not None:
            now.left = T(lst[i])
            q.append(now.left)
        i = i + 1
        if i < len(lst) and lst[i] is not None:
            now.right = T(lst[i])
            q.append(now.right)
        i = i + 1
    return root

def m(t1, t2):
    if not t1 and not t2:
        return True
    if not t1 or not t2:
        return False
    return (t1.val == t2.val) and m(t1.left, t2.right) and m(t1.right, t2.left)

def s1(root):
    if not root:
        return True
    return m(root.left, root.right)

def s2(root):
    if not root:
        return True
    q = deque([(root.left, root.right)])
    while q:
        t1, t2 = q.popleft()
        if not t1 and not t2:
            continue
        if not t1 or not t2 or t1.val != t2.val:
            return False
        q.append((t1.left, t2.right))
        q.append((t1.right, t2.left))
    return True

s = input("输入树的层序遍历：")
root = make(s)

print("递归法：", s1(root))
print("迭代法：", s2(root))
print("time1=O(n)")
print("time2=O(n)")
