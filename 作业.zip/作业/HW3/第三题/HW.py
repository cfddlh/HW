def t(x):
    a, b = x.split(":")
    return int(a) * 60 + int(b)

time = [
    ("9:00", "12:30"), ("11:00", "14:00"), ("13:00", "14:30"),
    ("9:00", "10:30"), ("13:00", "14:30"), ("14:00", "16:30"),
    ("15:00", "16:30"), ("15:00", "16:30"), ("9:00", "10:30")
]

a = []
for x in time:
    a.append((t(x[0]), t(x[1])))

a.sort()

h = []
b = []

for x in a:
    ok = 0
    for i in range(len(h)):
        if h[i][0] <= x[0]:
            h[i] = (x[1], h[i][1])
            b[h[i][1]].append(x)
            ok = 1
            break
    if not ok:
        b.append([x])
        h.append((x[1], len(b) - 1))
    h.sort()

print("教室数：", len(b))
for i in range(len(b)):
    print("教室", i + 1)
    for x in b[i]:
        print(" ", x[0] // 60, ":", f"{x[0] % 60:02}", "-", x[1] // 60, ":", f"{x[1] % 60:02}", sep="")