class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def recover(root):
    nodes = []

    def inorder(node):
        if node:
            inorder(node.left)
            nodes.append(node)
            inorder(node.right)

    inorder(root)

    first = None
    second = None

    for i in range(len(nodes) - 1):
        if nodes[i].val > nodes[i + 1].val:
            if first is None:
                first = nodes[i]
            second = nodes[i + 1]

    if first and second:
        first.val, second.val = second.val, first.val

def tree(lst):
    if not lst or lst[0] is None:
        return None

    root = TreeNode(lst[0])
    q = [root]
    i = 1

    while q and i < len(lst):
        node = q.pop(0)

        if i < len(lst) and lst[i] is not None:
            node.left = TreeNode(lst[i])
            q.append(node.left)
        i += 1

        if i < len(lst) and lst[i] is not None:
            node.right = TreeNode(lst[i])
            q.append(node.right)
        i += 1

    return root

def list(root):
    if not root:
        return []

    result = []
    q = [root]

    while q:
        node = q.pop(0)
        if node:
            result.append(node.val)
            q.append(node.left)
            q.append(node.right)
        else:
            result.append(None)

    while result and result[-1] is None:
        result.pop()

    return result

print("请输入二叉树的列表表示[a,b,c]：")
tree_input = eval(input("输入："))
root = tree(tree_input)
recover(root)
print("\n恢复后的树结构：", list(root))
print("time=O(n)")