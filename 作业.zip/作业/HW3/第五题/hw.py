a = [(5, 10), (4, 40), (6, 30), (3, 50)]
w = 9
n = len(a)
d = [0] * (w + 1)

for i in range(n):
    for j in range(w, a[i][0] - 1, -1):
        d[j] = max(d[j], d[j - a[i][0]] + a[i][1])

print("最大价值为：", d[w])
print("time = O(nw)")