def find(x, y):
    if x < 0 or y < 0 or x >= h or y >= w or g[x][y] != '1':
        return
    g[x][y] = '0'
    find(x+1, y)
    find(x-1, y)
    find(x, y+1)
    find(x, y-1)

g = []
n = int(input("输入行数: "))
for i in range(n):
    g.append(input("输入第{}行: ".format(i+1)).split())

h = len(g)
w = len(g[0])
ans = 0

for i in range(h):
    for j in range(w):
        if g[i][j] == '1':
            ans += 1
            find(i, j)

print("岛屿数量是:", ans)
print("time=O(hw)")