def Sum(S, W):
    n = len(S)
    dp = [False] * (W + 1)
    dp[0] = True

    for i in range(n):

        for j in range(W, S[i] - 1, -1):
            if dp[j - S[i]]:
                dp[j] = True

    return dp[W]

S = list(map(int, input("请输入数组：").split()))
W = int(input("请输入目标值W："))

if Sum(S, W):
    print("True")
else:
    print("False")