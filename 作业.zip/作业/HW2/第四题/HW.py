a = list(map(int, input("输入星球数组：").split()))
stk = []
for x in a:
    while stk and x < 0 and stk[-1] > 0:
        if abs(x) > stk[-1]:
            stk.pop()
        elif abs(x) == stk[-1]:
            break
        else:
            x = 0
            break
    else:
        if x != 0:
            stk.append(x)
print(stk)
print("time=O(n)")