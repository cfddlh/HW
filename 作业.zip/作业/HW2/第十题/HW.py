x = input("输入字符串x：")
y = input("输入字符串y：")

n = len(x)
m = len(y)

dp = [[0] * (m + 1) for _ in range(n + 1)]

for i in range(n + 1):
    for j in range(m + 1):
        if i == 0:
            dp[i][j] = j
        elif j == 0:
            dp[i][j] = i
        elif x[i - 1] == y[j - 1]:
            dp[i][j] = dp[i - 1][j - 1]
        else:
            a = dp[i][j - 1]
            b = dp[i - 1][j]
            c = dp[i - 1][j - 1]
            dp[i][j] = min(a, b, c) + 1

print("最少操作次数是：", dp[n][m])