s = input("输入数组：")
a = list(map(int, s.strip().split()))
t = int(input("输入目标值："))

d = {}
for i in range(len(a)):
    x = a[i]
    y = t - x
    if y in d:
        print([d[y], i])
        break
    d[x] = i
    print("time=O(n)")