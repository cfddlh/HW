def fun(num, cap, wt, val):
    box = [[[0 for _ in range(cap + 1)] for _ in range(cap + 1)] for _ in range(num + 1)]

    for i in range(1, num + 1):
        for a in range(cap + 1):
            for b in range(cap + 1):
                box[i][a][b] = box[i - 1][a][b]
                if a >= wt[i - 1]:
                    temp = box[i - 1][a - wt[i - 1]][b] + val[i - 1]
                    if temp > box[i][a][b]:
                        box[i][a][b] = temp
                if b >= wt[i - 1]:
                    temp = box[i - 1][a][b - wt[i - 1]] + val[i - 1]
                    if temp > box[i][a][b]:
                        box[i][a][b] = temp

    print("最大价值:", box[num][cap][cap])

    a = cap
    b = cap
    things = []
    i = num
    while i > 0:
        now = box[i][a][b]
        before = box[i - 1][a][b]
        if now != before:
            if a >= wt[i - 1] and box[i - 1][a - wt[i - 1]][b] + val[i - 1] == now:
                things.append(i - 1)
                a = a - wt[i - 1]
            elif b >= wt[i - 1] and box[i - 1][a][b - wt[i - 1]] + val[i - 1] == now:
                things.append(i - 1)
                b = b - wt[i - 1]
        i = i - 1

    print("背包里的物品下标:", things)


num = int(input("请输入物品数量: "))
wt = list(map(int, input("请输入每个物品的重量: ").split()))
val = list(map(int, input("请输入每个物品的价值: ").split()))
cap = int(input("请输入每个背包的容量: "))

fun(num, cap, wt, val)