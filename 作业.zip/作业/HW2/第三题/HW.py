def cal(a, b, op):
    if op == '+':
        return a + b
    if op == '-':
        return a - b
    if op == '*':
        return a * b
    if op == '/':
        return a // b

def pri(op):
    if op == '+' or op == '-':
        return 1
    if op == '*' or op == '/':
        return 2
    return 0

s = input("输入表达式：")
nums = []
ops = []
i = 0
while i < len(s):
    if s[i].isdigit():
        j = i
        while j < len(s) and s[j].isdigit():
            j += 1
        nums.append(int(s[i:j]))
        i = j
    else:
        while ops and pri(ops[-1]) >= pri(s[i]):
            b = nums.pop()
            a = nums.pop()
            o = ops.pop()
            nums.append(cal(a, b, o))
        ops.append(s[i])
        i += 1

while ops:
    b = nums.pop()
    a = nums.pop()
    o = ops.pop()
    nums.append(cal(a, b, o))

print(nums[0])
print("time=O(n)")