def fun(s):
    n = len(s)
    res = 0
    for i in range(n):
        a = i
        b = i
        while a >= 0 and b < n and s[a] == s[b]:
            if b - a + 1 > res:
                res = b - a + 1
            a = a - 1
            b = b + 1
        a = i
        b = i + 1
        while a >= 0 and b < n and s[a] == s[b]:
            if b - a + 1 > res:
                res = b - a + 1
            a = a - 1
            b = b + 1
    return res

x = input("请输入一个字符串：")
print("最长回文子串长度是：", fun(x))
print("time=O(n^2)")