class nod:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def add(tree, val):
    if tree is None:
        return nod(val)
    if val < tree.val:
        tree.left = add(tree.left, val)
    else:
        tree.right = add(tree.right, val)
    return tree

def rem(tree, key):
    if tree is None:
        return tree
    if key < tree.val:
        tree.left = rem(tree.left, key)
    elif key > tree.val:
        tree.right = rem(tree.right, key)
    else:
        if tree.left is None:
            return tree.right
        elif tree.right is None:
            return tree.left
        small = find(tree.right)
        tree.val = small.val
        tree.right = rem(tree.right, tree.val)
    return tree

def find(tree):
    while tree.left is not None:
        tree = tree.left
    return tree

def inorder(tree):
    if tree is not None:
        inorder(tree.left)
        print(tree.val, end=" ")
        inorder(tree.right)

nums = [9, -3, -10, 0, 9, 7, 33]
root = None

for num in nums:
    root = add(root, num)

root = rem(root, 0)

print("中序遍历结果：", end="")
inorder(root)
print()
print("time=O(nlogn)")