class NodeList:
    def __init__(self, val=None, right=None):
        self.val = val
        self.right = right

def A(arr):
    if not arr:
        return None
    head = NodeList(arr[0])
    c = head
    for v in arr[1:]:
        c.right = NodeList(v)
        c = c.right
    return head

def B(head):
    c = head
    while c and c.right:
        if c.val == c.right.val:
            c.right = c.right.right
        else:
            c = c.right
    return head

def C(head):
    result = []
    while head:
        result.append(head.val)
        head = head.right
    return result

input_str = input("请输入升序数组：")
arr = list(map(int, input_str.strip().split()))

head = A(arr)
head = B(head)
output = C(head)

print(output)
print("time=O(n)")